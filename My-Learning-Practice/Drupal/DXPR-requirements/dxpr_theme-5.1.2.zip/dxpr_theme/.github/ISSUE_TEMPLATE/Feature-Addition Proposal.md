---
name: Feature-Addition Proposal
about: Use this template to propose an addition to an existing feature.
title: "FEATURE DESCRIPTION"
labels: 2.x,feature addition proposal
---

<!-- This template is a great use for issues that are feature::additions or technical tasks for larger issues.-->

### Proposal

<!-- Use this section to explain the feature and how it will work. It can be helpful to add technical details, design proposals, and links to related initiatives or issues. -->

<!-- Consider adding related issues and initiatives to this issue. You can also reference the Feature Proposal Template for additional details to consider adding to this issue. Additionally, as a data oriented organization, when your feature exits planning breakdown, consider adding the `What does success look like, and how can we measure that?` section.
-->